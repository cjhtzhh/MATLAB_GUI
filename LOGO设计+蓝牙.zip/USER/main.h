#ifndef MAIN_H_
#define MAIN_H_

#include "delay.h"
#include "sys.h"
#include "usart.h"
#include "led.h"
#include "lcd.h"
#include "show.h"
#include "touch.h"
#include "24cxx.h"
#include "beep.h"
#include "key.h" 
#include "delay.h"
#include "tsensor.h"
#include "usart3.h" 			 
#include "hc05.h" 
#include "timer.h"

#include "math.h"
#include "string.h"
#include "stdarg.h"	 	 
#include "stdio.h"	

extern u8 key,t,temperature,humidity;
#endif
