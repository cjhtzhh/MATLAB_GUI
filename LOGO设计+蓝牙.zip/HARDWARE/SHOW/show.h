#ifndef __SHOW_H
#define __SHOW_H	
#include "sys.h"

void Show_Interface(void);
void Show_Choose(void);
void Interface(void);
void HC_Mode(void);
#endif
